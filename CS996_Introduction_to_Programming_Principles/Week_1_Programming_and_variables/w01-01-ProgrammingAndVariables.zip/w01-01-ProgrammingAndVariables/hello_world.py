"""
A program to introduce Python.
"""

print("Well hello there!")
