"""
Python: Functions: Q1
"""


def multiply(x, y):
    """
    A function to multiply two numbers together
    and return the result.
    """
    return x * y
