"""
Python: Functions: Q2
"""


def append_two(values):
    """
    A function to append two values to a list.
    """
    values.append(1)
    values.append(2)


input_values = []
append_two(input_values)
print(input_values)
