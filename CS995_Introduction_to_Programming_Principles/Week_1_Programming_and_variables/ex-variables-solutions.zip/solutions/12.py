"""
Python: Using variables: Q12
"""


values = {}
value = values[1]
