"""
Python: Using variables: Q13
"""


values = []
value = [0]
