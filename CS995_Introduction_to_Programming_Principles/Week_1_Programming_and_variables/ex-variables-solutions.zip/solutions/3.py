"""
Python: Using variables: Q3
"""


import math
r = 2.3
a = math.pi * math.pow(r, 2)
print(r)
print(a)
