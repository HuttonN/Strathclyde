"""
Python: Using variables: Q6
"""


s1 = "Gone down moor"
s2 = "Fishing"
print(s1[0:2])
s3 = s1[0:2] + s2[0:2]
print(s1)
print(s2)
print(s3)
