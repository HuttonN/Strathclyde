"""
Python: Using variables: Q4
"""


citations = {
  "H. B. Potter": 100,
  "C. S. Lewis": 400,
  "A. A. Milne": 300,
  "P. G. Wodehouse": 200
}
print(citations["C. S. Lewis"])
print(citations["P. G. Wodehouse"])
