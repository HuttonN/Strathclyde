"""
Python: Using variables: Q8
"""


s = "2.5"
f = 10.5
f2 = f + float(s)
print(s)
print(f)
print(f2)
