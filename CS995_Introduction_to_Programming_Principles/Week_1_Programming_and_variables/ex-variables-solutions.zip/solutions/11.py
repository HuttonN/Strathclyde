"""
Python: Using variables: Q11
"""


letters = {
    "a": [1, 2],
    "b": [2, 1]
}
print(letters)
