"""
Python: Using variables: Q9
"""


s = "2n"
i = int(s)
