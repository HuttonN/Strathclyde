"""
Python: Using variables: Q5
"""


i = 3
j = 2
result = i/j
print(type(result))
