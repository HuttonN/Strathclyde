"""
Python: Using variables: Q1
"""


i = 2
j = 3
k = i + j
print(i)
print(j)
print(k)
