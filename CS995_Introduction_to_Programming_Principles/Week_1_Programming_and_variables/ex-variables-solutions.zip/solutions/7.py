"""
Python: Using variables: Q7
"""


i = 2
s = "a"
s2 = s + str(i)
print(s2)
