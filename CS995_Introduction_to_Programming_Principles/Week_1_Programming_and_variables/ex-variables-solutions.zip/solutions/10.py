"""
Python: Using variables: Q10
"""


values = [
    [1, 3],
    [3, 1]
]
print(values)
