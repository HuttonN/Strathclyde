"""
Python: Using variables: Q2
"""


values = [
    4,
    3,
    1,
    7
]
print(values)
values.sort()
print(values)
