import os.path


"""
A program to demonstrate joining a file path.
"""
file_path = os.path.join("my_dir", "my-file.txt")
print(f"file_path=\"{file_path}\"")
