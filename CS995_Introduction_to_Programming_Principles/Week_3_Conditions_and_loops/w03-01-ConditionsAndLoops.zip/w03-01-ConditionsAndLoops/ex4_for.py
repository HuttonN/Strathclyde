"""
A program to demonstrate accessing list elements,
using a index within a for loop.
"""


numbers = [2, 4, 5]
n = len(numbers)
for i in range(n):
    print(i, numbers[i])
