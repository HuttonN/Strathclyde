"""
A program that uses a for loop to consider
each value in a list.
"""


numbers = [2, 4, 5]
for number in numbers:
    print(number)
