"""
A program to demonstrate a conditional statement.
"""


# This value could be set somewhere else in the program.
x = 3

# Test if the value is within limits.
if x < 4 and x > 0:
    print("Small value")
else:
    print("Out of range.")
