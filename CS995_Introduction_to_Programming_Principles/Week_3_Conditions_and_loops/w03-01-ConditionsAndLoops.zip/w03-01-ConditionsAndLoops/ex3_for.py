"""
A program that demonstrates range() with
a for loop.
"""


# Loop from 1 to 5, increasing in steps of 2.
for i in range(1, 6, 2):
    print(i)
