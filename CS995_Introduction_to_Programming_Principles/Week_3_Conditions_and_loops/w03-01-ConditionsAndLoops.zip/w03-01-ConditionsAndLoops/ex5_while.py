"""
A program to demonstrate a while loop.
"""

# Print the numbers from 0 to 2.
i = 0
while i < 3:
    print(i)
    i += 1
