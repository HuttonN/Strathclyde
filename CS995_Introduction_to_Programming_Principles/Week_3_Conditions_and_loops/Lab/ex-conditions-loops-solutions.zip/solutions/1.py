"""
Python: Conditions and loops: Q1
"""


values = {
    "a": 2,
    "b": 3
}
for key in values.keys():
    print(key)
