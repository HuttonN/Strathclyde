"""
Python: Conditions and loops: Q2
"""


sum = 0
for i in range(5, 16):
    sum += i
print(sum)
