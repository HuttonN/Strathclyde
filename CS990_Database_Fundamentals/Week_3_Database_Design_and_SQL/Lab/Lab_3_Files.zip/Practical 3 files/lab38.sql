REM lab48.sql

ALTER TABLE TEAM
	ADD ( Manager_name	CHAR(20) );

