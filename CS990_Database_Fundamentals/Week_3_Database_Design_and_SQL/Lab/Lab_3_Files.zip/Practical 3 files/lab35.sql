REM lab35.sql

create index t1index on game( team_1 );
create index t2index on game (team_2);
