REM lab31.sql

create table team (
	TNO		NUMBER (2),
	TNA		CHAR (20),
	GRP	 	CHAR (1) 
);
