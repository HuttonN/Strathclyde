import java.util.List;
import java.util.ArrayList;
/**
 * Represents a library member who can borrow and return physical books.
 * Each library member has a unique ID and a list of borrowed books.
 * 
 * Provides methods for borrowing, returning, and viewing borrowed books.
 * 
 * Version 1.1 Notes:
 * - Added the getDetails method to generate member details as a String.
 * - Modified the printDetails method to use getDetails() for better testability
 * 
 * 
 * @author Neil Hutton
 * @version 1.1
 */
public class LibraryMember {
    private int id;
    private List<PhysicalBook> borrowedBooks;

    /**
     * Constructs a new LibraryMember with the specified ID.
     * 
     * @param id the unique ID of the library member
     */
    public LibraryMember(int id) {
        this.id = id;
        this.borrowedBooks = new ArrayList<>();
    }

    /**
     * Gets the ID of the library member.
     * 
     * @return the ID of the library member
     */
    public int getId() {
        return id;
    }
    
    /**
     * Sets the ID of the library member.
     * 
     * @param id the new ID of the library member
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * Gets the list of books currently borrowed by the library member.
     * 
     * @return a copy of the list of borrowed books for immutability
     */
    public List<PhysicalBook> getBorrowedBooks() {
        return new ArrayList<>(borrowedBooks);
    }
    
    /**
     * Adds a book to the member's list of borrowed books.
     * 
     * This method does not enforce borrowing rules (e.g., checking if the book is available 
     * or already borrowed by another member). Such logic is handled by the {@link Library} class.
     * 
     * Before adding the book, it checks if the book is already in the member's list of borrowed books.
     * 
     * @param book the book to add to the borrowed list
     */
    public void addBorrowedBook(PhysicalBook book){
        if (borrowedBooks.contains(book)){
            System.out.println("Error: Book is already borrowed by this member");
            return;
        } 
        
        borrowedBooks.add(book);
        System.out.println("Book '" + book.getTitle() + "' successfully borrowed by Member ID: " + id);
    }
    
    /**
     * Returns a book borrowed by the library member.
     * Removes the book from the member's list of borrowed books.
     * 
     * @param book the book to return
     */
    public void returnBook(PhysicalBook book){
        if (borrowedBooks.contains(book)){
            borrowedBooks.remove(book);
            System.out.println("Book '" + book.getTitle() + "' removed from Library Member ID: " + id + "'s borrowed books.");
        } else {
            System.out.println("Error: Book '" + book.getTitle() + "' is not in Library Member ID: " + id + "'s borrowed books.");
        }
    }
    
    /**
     * Gets the number of books currently borrowed by the library member.
     * 
     * @return the number of borrowed books
     */
    public int numberOfBorrowedBooks(){
        return borrowedBooks.size();
    }
    
    /**
     * Generates a string containing the details of the library member.
     * 
     * @return a string representation of the library member's details
     */
    public String getDetails(){
        String details = "Library Member ID: " + id + "\n";
        
        if (borrowedBooks.isEmpty()) {
            details += "Borrowed Books: None";
        } else {
            details += "Borrowed Books:\n";
            for (PhysicalBook book : borrowedBooks){
                details += book.getDetails() + "\n";
            }
        }
        return details;
    }
    
    /**
     * Prints the details of the library member to the console.
     */
    public void printDetails(){
        System.out.println(getDetails());
    }
}
